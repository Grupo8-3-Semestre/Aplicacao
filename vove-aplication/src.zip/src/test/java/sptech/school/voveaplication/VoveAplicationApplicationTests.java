package sptech.school.voveaplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoveAplicationApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
