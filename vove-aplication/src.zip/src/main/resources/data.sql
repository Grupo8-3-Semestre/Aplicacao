  insert into usuario
  (nome, email, senha, data_nasc, aceita_email)
    values
    ('John Doe', 'john.doe@gmail.com', '$2a$10$0/TKTGxdREbWaWjWYhwf6e9P1fPOAMMNqEnZgOG95jnSkHSfkkIrC', '2000-08-20', true);